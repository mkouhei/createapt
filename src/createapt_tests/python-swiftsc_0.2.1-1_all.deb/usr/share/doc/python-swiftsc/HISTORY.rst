History
-------

0.2.1 (2012-05-17)
^^^^^^^^^^^^^^^^^^

* change api of retrieve_object(), response inserted boolean before content

0.2 (2012-05-10)
^^^^^^^^^^^^^^^^

* add is_object method
* change api of is_container, response is changed status code to boolean

0.1.3 (2012-05-08)
^^^^^^^^^^^^^^^^^^

* fixes the response is not invalid with Response.json in requests 1.0 later

0.1.2 (2012-05-07)
^^^^^^^^^^^^^^^^^^

* set default timeout as 5.0

0.1.1 (2012-05-05)
^^^^^^^^^^^^^^^^^^

* fixes failed to upload without "Content-Length" when uploading empty file

0.1 (2012-05-02)
^^^^^^^^^^^^^^^^

* first release

