History
-------

0.3 (2012-05-17)
^^^^^^^^^^^^^^^^

* add retrieve backup object command

0.2 (2012-05-10)
^^^^^^^^^^^^^^^^

* add backup object command
* fixes man manual

0.1.3 (2012-05-10)
^^^^^^^^^^^^^^^^^^

* applied changing api of swiftsc.client.is_container()
* add how to setup and usage

0.1.2 (2012-05-09)
^^^^^^^^^^^^^^^^^^

* fixes #3 failed to execute in python2.6

0.1.1 (2012-05-08)
^^^^^^^^^^^^^^^^^^

* fixes #1 fail to execute firstly when there is no container

0.1 (2012-05-08)
^^^^^^^^^^^^^^^^

* first release

